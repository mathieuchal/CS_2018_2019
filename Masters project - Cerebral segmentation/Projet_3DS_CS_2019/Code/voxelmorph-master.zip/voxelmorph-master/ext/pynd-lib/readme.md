# ND utilities
Python Library for ND (n-dimensional) array operations