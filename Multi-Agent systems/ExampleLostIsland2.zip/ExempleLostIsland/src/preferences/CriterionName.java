package preferences;

public enum CriterionName {
	DRINK, FOOD, COST;
}
