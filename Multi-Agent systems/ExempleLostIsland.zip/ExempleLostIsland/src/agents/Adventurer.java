package agents;

import jade.core.Agent;
import preferences.CriterionName;
import preferences.CriterionValue;
import preferences.Item;
import preferences.Preferences;
import preferences.Value;

public class Adventurer extends Agent {

	Preferences pref = new Preferences();
	
	public void setup() {
		
		pref.setOrderCriteria(new CriterionName[] {
				CriterionName.DRINK,
				CriterionName.FOOD,
				CriterionName.COST});

		Item water_bottle = new Item("A super cool bottle of water");
		pref.add(new CriterionValue(water_bottle,CriterionName.COST,Value.AVERAGE));
		pref.add(new CriterionValue(water_bottle,CriterionName.FOOD,Value.USELESS));
		pref.add(new CriterionValue(water_bottle,CriterionName.DRINK,Value.VERY_USEFUL));

		Item shoes = new Item("A pair of shoes");
		pref.add(new CriterionValue(shoes,CriterionName.COST,Value.AVERAGE));
		pref.add(new CriterionValue(shoes,CriterionName.FOOD,Value.USELESS));
		pref.add(new CriterionValue(shoes,CriterionName.DRINK,Value.USELESS));

		
		System.out.println("An adventurer is ready to negotiate");
	}
}
